EN:
This project is based on the zapret-discord-youtube project, but I (PonerKa) decided to make my own zapret, which allows you to unlock YouTube, Discord, and Roblox! If anything else is blocked or the ban is blocked, new versions with a fix will be released! By Ponerka

RU
Этот проект основан на проекте zapret-discord-youtube, но я (PonerKa) решила создать свой собственный zapret, который позволит вам разблокировать YouTube, Discord и Roblox! Если что-то еще будет заблокировано или запрет будет снят, будут выпущены новые версии с исправлениями! 



Author Ponerka